﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EjercicioPractico1EVA_ALB
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCalculo_Click(object sender, RoutedEventArgs e)
        {
            float distancia;
            if (tbDistancia.Text == "")
            {
                MessageBox.Show("Introduce una distancia");
                return;
            }
            if (tbDistancia!=null)
            {
                distancia = float.Parse(tbDistancia.Text);
            }
            else
            {
                MessageBox.Show("Introduce una distancia");
                return;
            }
           
            if ((bool)rbAndando.IsChecked)
            {



                float minutos1Hora = 60;
                float segundosHora = 3600;
                float velocidadAndando = 5;
                float velocidadPorKM = minutos1Hora / velocidadAndando;
                float velocidadTotal = distancia * velocidadPorKM;
                float velocidadTotalsegundos = distancia * segundosHora;
                float hora = velocidadTotal / minutos1Hora;
                float minutos = velocidadTotal % minutos1Hora;
                float segundos = velocidadTotalsegundos / segundosHora;




                lbTiempo.Content = "Tiempo: " + hora.ToString("N0") + " horas " + minutos.ToString("N0") +
                    " minutos " + segundos.ToString("N0") + " segundos";

            }
            if ((bool)rbBici.IsChecked)
            {


                float minutos1Hora = 60;
                float segundosHora = 3600;
                float velocidadBici = 20;
                float velocidadPorKM = minutos1Hora / velocidadBici;
                float velocidadTotal = distancia * velocidadPorKM;
                float velocidadTotalsegundos = distancia * segundosHora;
                float hora = velocidadTotal / minutos1Hora;
                float minutos = velocidadTotal % minutos1Hora;
                float segundos = velocidadTotalsegundos / segundosHora;




                lbTiempo.Content = "Tiempo: " + hora.ToString("N0") + " horas " + minutos.ToString("N0") +
                    " minutos " + segundos.ToString("N0") + " segundos";
            }
            if((bool)rbCoche.IsChecked)
            {


                float minutos1Hora = 60;
                float segundosHora = 3600;
                float velocidadCoche = 75;
                float velocidadPorKM = minutos1Hora / velocidadCoche;
                float velocidadTotal = distancia * velocidadPorKM;
                float velocidadTotalsegundos = distancia * segundosHora;
                float hora = velocidadTotal / minutos1Hora;
                float minutos = velocidadTotal % minutos1Hora;
                float segundos = velocidadTotalsegundos / segundosHora;



                lbTiempo.Content = "Tiempo: " + hora.ToString("N0") + " horas " + minutos.ToString("N0") +
                    " minutos " + segundos.ToString("N0")+ " segundos";

            }
            if((bool)rbPatinete.IsChecked)
            {

                float minutos1Hora = 60;
                float segundosHora = 3600;
                float velocidadPatinete = 25;
                float velocidadPorKM = minutos1Hora / velocidadPatinete;
                float velocidadTotal = distancia * velocidadPorKM;
                float velocidadTotalsegundos = distancia * segundosHora;
                float hora = velocidadTotal / minutos1Hora;
                float minutos = velocidadTotal % minutos1Hora;
                float segundos = velocidadTotalsegundos / segundosHora;




                lbTiempo.Content = "Tiempo: " + hora.ToString("N0") + " horas " + minutos.ToString("N0") +
                    " minutos " + segundos.ToString("N0") + " segundos";
            }



        }
    }
}
